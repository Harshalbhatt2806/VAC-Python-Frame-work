from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Category, Expense


class BaseTestCase(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user('alice', password='StrongPass!234')
        self.bob = User.objects.create_user('bob', password='StrongPass!234')
        self.a_cat = Category.objects.create(user=self.alice, name='Food')
        self.b_cat = Category.objects.create(user=self.bob, name='Food')

    def make_expense(self, user, category, amount='10.00', when=None, title='Lunch'):
        return Expense.objects.create(
            user=user, category=category, title=title, amount=Decimal(amount),
            date=when or timezone.localdate(), payment_method='cash',
        )


class AuthTests(BaseTestCase):
    def test_register_creates_user_and_default_categories(self):
        resp = self.client.post(reverse('register'), {
            'username': 'newuser', 'email': 'n@example.com',
            'password1': 'Sup3rSecret!pw', 'password2': 'Sup3rSecret!pw'})
        self.assertRedirects(resp, reverse('dashboard'))
        user = User.objects.get(username='newuser')
        self.assertTrue(user.check_password('Sup3rSecret!pw'))
        self.assertTrue(Category.objects.filter(user=user, name='Food').exists())

    def test_register_password_mismatch(self):
        resp = self.client.post(reverse('register'), {
            'username': 'x', 'email': '', 'password1': 'Sup3rSecret!pw', 'password2': 'different'})
        self.assertContains(resp, 'do not match')
        self.assertFalse(User.objects.filter(username='x').exists())

    def test_login_and_logout(self):
        self.assertTrue(self.client.login(username='alice', password='StrongPass!234'))
        self.assertEqual(self.client.get(reverse('dashboard')).status_code, 200)
        self.client.post(reverse('logout'))
        self.assertEqual(self.client.get(reverse('dashboard')).status_code, 302)

    def test_login_view_bad_credentials(self):
        resp = self.client.post(reverse('login'), {'username': 'alice', 'password': 'nope'})
        self.assertContains(resp, 'Incorrect username or password')

    def test_private_pages_require_login(self):
        urls = [reverse(n) for n in ('dashboard', 'expense_list', 'expense_add',
                                     'category_list', 'category_add', 'monthly_report')]
        urls += [reverse('expense_edit', args=[1]), reverse('expense_delete', args=[1]),
                 reverse('category_edit', args=[1]), reverse('category_delete', args=[1])]
        for url in urls:
            resp = self.client.get(url)
            self.assertEqual(resp.status_code, 302, url)
            self.assertIn(reverse('login'), resp.url)


class ModelTests(BaseTestCase):
    def test_duplicate_category_same_user_blocked_case_insensitive(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            Category.objects.create(user=self.alice, name='food')

    def test_same_category_name_allowed_for_different_users(self):
        self.assertEqual(Category.objects.filter(name='Food').count(), 2)

    def test_expense_category_owner_must_match(self):
        from django.core.exceptions import ValidationError
        e = Expense(user=self.alice, category=self.b_cat, title='x', amount=Decimal('5'), date=date.today())
        with self.assertRaises(ValidationError):
            e.full_clean()

    def test_str(self):
        e = self.make_expense(self.alice, self.a_cat, '12.5', title='Tea')
        self.assertEqual(str(e), 'Tea - 12.50')
        self.assertEqual(str(self.a_cat), 'Food')


class ExpenseCrudTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.client.login(username='alice', password='StrongPass!234')

    def payload(self, **kw):
        data = {'title': 'Dinner', 'amount': '25.50', 'category': self.a_cat.pk,
                'date': '2026-03-10', 'payment_method': 'card', 'description': ''}
        data.update(kw)
        return data

    def test_add_expense(self):
        resp = self.client.post(reverse('expense_add'), self.payload(), follow=True)
        self.assertContains(resp, 'Expense added successfully')
        e = Expense.objects.get(title='Dinner')
        self.assertEqual(e.user, self.alice)
        self.assertEqual(e.amount, Decimal('25.50'))

    def test_add_rejects_non_positive_amount(self):
        for bad in ('0', '-5'):
            resp = self.client.post(reverse('expense_add'), self.payload(amount=bad))
            self.assertContains(resp, 'greater than zero')
        self.assertEqual(Expense.objects.count(), 0)

    def test_add_requires_fields(self):
        resp = self.client.post(reverse('expense_add'), {})
        self.assertContains(resp, 'Please enter a title.')
        self.assertContains(resp, 'Please enter an amount.')
        self.assertContains(resp, 'Please choose a date.')

    def test_cannot_use_other_users_category(self):
        resp = self.client.post(reverse('expense_add'), self.payload(category=self.b_cat.pk))
        self.assertEqual(resp.status_code, 200)  # form re-rendered with an error
        self.assertEqual(Expense.objects.count(), 0)

    def test_category_choices_limited_to_user(self):
        resp = self.client.get(reverse('expense_add'))
        self.assertEqual(list(resp.context['form'].fields['category'].queryset), [self.a_cat])

    def test_edit_expense(self):
        e = self.make_expense(self.alice, self.a_cat)
        resp = self.client.post(reverse('expense_edit', args=[e.pk]), self.payload(title='Changed'), follow=True)
        self.assertContains(resp, 'Expense updated successfully')
        e.refresh_from_db()
        self.assertEqual(e.title, 'Changed')

    def test_delete_expense_with_confirmation(self):
        e = self.make_expense(self.alice, self.a_cat)
        self.assertContains(self.client.get(reverse('expense_delete', args=[e.pk])), 'Delete expense?')
        self.assertTrue(Expense.objects.filter(pk=e.pk).exists())  # GET does not delete
        self.client.post(reverse('expense_delete', args=[e.pk]))
        self.assertFalse(Expense.objects.filter(pk=e.pk).exists())

    def test_list_shows_two_decimals_and_search_filter(self):
        self.make_expense(self.alice, self.a_cat, '7', title='Coffee')
        self.make_expense(self.alice, self.a_cat, '9', title='Bus ticket')
        resp = self.client.get(reverse('expense_list'), {'q': 'coff'})
        self.assertContains(resp, 'Coffee')
        self.assertContains(resp, '7.00')
        self.assertNotContains(resp, 'Bus ticket')

    def test_list_category_and_date_filters(self):
        other = Category.objects.create(user=self.alice, name='Travel')
        self.make_expense(self.alice, self.a_cat, when=date(2026, 1, 5), title='Old food')
        self.make_expense(self.alice, other, when=date(2026, 2, 5), title='Taxi')
        resp = self.client.get(reverse('expense_list'), {'category': other.pk})
        self.assertContains(resp, 'Taxi'); self.assertNotContains(resp, 'Old food')
        resp = self.client.get(reverse('expense_list'), {'start': '2026-01-01', 'end': '2026-01-31'})
        self.assertContains(resp, 'Old food'); self.assertNotContains(resp, 'Taxi')

    def test_invalid_filters_do_not_crash(self):
        resp = self.client.get(reverse('expense_list'), {'start': 'garbage', 'category': 'abc'})
        self.assertEqual(resp.status_code, 200)


class CategoryTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.client.login(username='alice', password='StrongPass!234')

    def test_add_edit_delete_category(self):
        self.client.post(reverse('category_add'), {'name': 'Travel'})
        c = Category.objects.get(user=self.alice, name='Travel')
        self.client.post(reverse('category_edit', args=[c.pk]), {'name': 'Trips'})
        c.refresh_from_db(); self.assertEqual(c.name, 'Trips')
        self.client.post(reverse('category_delete', args=[c.pk]))
        self.assertFalse(Category.objects.filter(pk=c.pk).exists())

    def test_duplicate_category_rejected_by_form(self):
        resp = self.client.post(reverse('category_add'), {'name': 'food'})
        self.assertContains(resp, 'already have a category')
        self.assertEqual(Category.objects.filter(user=self.alice).count(), 1)

    def test_cannot_delete_category_with_expenses(self):
        self.make_expense(self.alice, self.a_cat)
        resp = self.client.post(reverse('category_delete', args=[self.a_cat.pk]), follow=True)
        self.assertContains(resp, 'Cannot delete')
        self.assertTrue(Category.objects.filter(pk=self.a_cat.pk).exists())


class OwnershipTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.b_exp = self.make_expense(self.bob, self.b_cat, title='Bob secret')
        self.client.login(username='alice', password='StrongPass!234')

    def test_other_users_expense_is_404(self):
        for name in ('expense_edit', 'expense_delete'):
            self.assertEqual(self.client.get(reverse(name, args=[self.b_exp.pk])).status_code, 404)
            self.assertEqual(self.client.post(reverse(name, args=[self.b_exp.pk])).status_code, 404)
        self.assertTrue(Expense.objects.filter(pk=self.b_exp.pk).exists())

    def test_other_users_category_is_404(self):
        for name in ('category_edit', 'category_delete'):
            self.assertEqual(self.client.get(reverse(name, args=[self.b_cat.pk])).status_code, 404)
            self.assertEqual(self.client.post(reverse(name, args=[self.b_cat.pk])).status_code, 404)

    def test_lists_do_not_leak(self):
        for name in ('expense_list', 'dashboard', 'monthly_report', 'category_list'):
            self.assertNotContains(self.client.get(reverse(name)), 'Bob secret')


class DashboardAndReportTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.client.login(username='alice', password='StrongPass!234')
        self.travel = Category.objects.create(user=self.alice, name='Travel')

    def test_dashboard_empty(self):
        resp = self.client.get(reverse('dashboard'))
        self.assertEqual(resp.context['record_count'], 0)
        self.assertEqual(resp.context['month_total'], 0)
        self.assertIsNone(resp.context['top_category'])

    def test_dashboard_aggregates(self):
        today = timezone.localdate()
        self.make_expense(self.alice, self.a_cat, '10.00', today)
        self.make_expense(self.alice, self.travel, '40.50', today)
        self.make_expense(self.alice, self.travel, '100.00', date(2000, 1, 1))  # old
        self.make_expense(self.bob, self.b_cat, '999.00', today)               # other user
        ctx = self.client.get(reverse('dashboard')).context
        self.assertEqual(ctx['today_total'], Decimal('50.50'))
        self.assertEqual(ctx['month_total'], Decimal('50.50'))
        self.assertEqual(ctx['record_count'], 3)
        self.assertEqual(ctx['top_category']['category__name'], 'Travel')
        self.assertEqual(ctx['top_category']['total'], Decimal('140.50'))
        self.assertEqual(len(ctx['recent_expenses']), 3)

    def test_recent_expenses_limited_to_five(self):
        for i in range(8):
            self.make_expense(self.alice, self.a_cat, '1.00', title=f'e{i}')
        self.assertEqual(len(self.client.get(reverse('dashboard')).context['recent_expenses']), 5)

    def test_monthly_totals(self):
        self.make_expense(self.alice, self.a_cat, '10.00', date(2026, 3, 1))
        self.make_expense(self.alice, self.a_cat, '5.25', date(2026, 3, 31))
        self.make_expense(self.alice, self.travel, '20.00', date(2026, 3, 15))
        self.make_expense(self.alice, self.travel, '77.00', date(2026, 4, 1))  # other month
        ctx = self.client.get(reverse('monthly_report'), {'year': 2026, 'month': 3}).context
        self.assertEqual(ctx['total'], Decimal('35.25'))
        totals = {r['category__name']: r['total'] for r in ctx['category_totals']}
        self.assertEqual(totals, {'Food': Decimal('15.25'), 'Travel': Decimal('20.00')})

    def test_monthly_date_range_filter(self):
        self.make_expense(self.alice, self.a_cat, '10.00', date(2026, 3, 1))
        self.make_expense(self.alice, self.a_cat, '5.00', date(2026, 3, 20))
        ctx = self.client.get(reverse('monthly_report'),
                              {'year': 2026, 'month': 3, 'start': '2026-03-10', 'end': '2026-03-31'}).context
        self.assertEqual(ctx['total'], Decimal('5.00'))

    def test_empty_month(self):
        resp = self.client.get(reverse('monthly_report'), {'year': 2026, 'month': 2})
        self.assertContains(resp, 'No expenses recorded for this period.')
        self.assertEqual(resp.context['total'], 0)

    def test_invalid_month_year_handled(self):
        for params in ({'year': 'abc', 'month': 3}, {'year': 2026, 'month': 13}, {'year': 2026, 'month': 0},
                       {'year': 99999, 'month': 1}):
            resp = self.client.get(reverse('monthly_report'), params)
            self.assertEqual(resp.status_code, 200)
            self.assertContains(resp, 'Invalid year or month')
