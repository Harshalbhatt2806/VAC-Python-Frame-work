import calendar
from datetime import date

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import CategoryForm, ExpenseForm, RegistrationForm
from .models import Category, Expense

DEFAULT_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Other']


def create_default_categories(user):
    """Create starter categories for a new user (skips names that already exist)."""
    for name in DEFAULT_CATEGORIES:
        if not Category.objects.filter(user=user, name__iexact=name).exists():
            Category.objects.create(user=user, name=name)


def chart_data(queryset):
    """Return (labels, values) lists of category-wise totals; templates use json_script."""
    rows = queryset.values('category__name').annotate(total=Sum('amount')).order_by('-total')
    labels = [r['category__name'] for r in rows]
    values = [float(r['total']) for r in rows]
    return labels, values


def parse_date(value):
    """Parse YYYY-MM-DD safely; return None when blank or invalid."""
    try:
        return date.fromisoformat(value) if value else None
    except ValueError:
        return None


# ---------- Authentication ----------

def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = RegistrationForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        create_default_categories(user)
        login(request, user)
        messages.success(request, 'Welcome! Your account has been created.')
        return redirect('dashboard')
    return render(request, 'tracker/register.html', {'form': form})


# ---------- Dashboard ----------

@login_required
def dashboard(request):
    expenses = Expense.objects.filter(user=request.user)
    today = timezone.localdate()

    month_total = expenses.filter(date__year=today.year, date__month=today.month).aggregate(t=Sum('amount'))['t'] or 0
    today_total = expenses.filter(date=today).aggregate(t=Sum('amount'))['t'] or 0
    top_category = (
        expenses.values('category__name').annotate(total=Sum('amount')).order_by('-total').first()
    )
    labels, values = chart_data(expenses)

    context = {
        'month_total': month_total,
        'today_total': today_total,
        'record_count': expenses.count(),
        'top_category': top_category,
        'recent_expenses': expenses.select_related('category')[:5],
        'chart_labels': labels,
        'chart_values': values,
    }
    return render(request, 'tracker/dashboard.html', context)


# ---------- Expenses ----------

@login_required
def expense_list(request):
    expenses = Expense.objects.filter(user=request.user).select_related('category')

    q = request.GET.get('q', '').strip()
    category_id = request.GET.get('category', '').strip()
    start = parse_date(request.GET.get('start', ''))
    end = parse_date(request.GET.get('end', ''))

    if q:
        expenses = expenses.filter(title__icontains=q)
    if category_id.isdigit():
        expenses = expenses.filter(category_id=int(category_id))
    if start:
        expenses = expenses.filter(date__gte=start)
    if end:
        expenses = expenses.filter(date__lte=end)
    if start and end and start > end:
        messages.warning(request, 'The start date is after the end date, so no results are shown.')

    total = expenses.aggregate(t=Sum('amount'))['t'] or 0
    page = Paginator(expenses, 10).get_page(request.GET.get('page'))

    params = request.GET.copy()
    params.pop('page', None)

    context = {
        'page_obj': page,
        'total': total,
        'categories': Category.objects.filter(user=request.user),
        'q': q,
        'selected_category': category_id,
        'start': request.GET.get('start', ''),
        'end': request.GET.get('end', ''),
        'querystring': params.urlencode(),
    }
    return render(request, 'tracker/expense_list.html', context)


@login_required
def expense_add(request):
    form = ExpenseForm(request.POST if request.method == 'POST' else None, user=request.user, initial={'date': timezone.localdate()})
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Expense added successfully.')
        return redirect('expense_list')
    return render(request, 'tracker/expense_form.html', {'form': form, 'title': 'Add Expense'})


@login_required
def expense_edit(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)  # 404 for other users' records
    form = ExpenseForm(request.POST if request.method == 'POST' else None, instance=expense, user=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Expense updated successfully.')
        return redirect('expense_list')
    return render(request, 'tracker/expense_form.html', {'form': form, 'title': 'Edit Expense'})


@login_required
def expense_delete(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == 'POST':
        expense.delete()
        messages.success(request, 'Expense deleted.')
        return redirect('expense_list')
    return render(request, 'tracker/expense_confirm_delete.html', {'expense': expense})


# ---------- Categories ----------

@login_required
def category_list(request):
    categories = Category.objects.filter(user=request.user).annotate(
        expense_count=Count('expenses'), total=Sum('expenses__amount')
    )
    return render(request, 'tracker/category_list.html', {'categories': categories})


@login_required
def category_add(request):
    form = CategoryForm(request.POST if request.method == 'POST' else None, user=request.user)
    if request.method == 'POST' and form.is_valid():
        category = form.save(commit=False)
        category.user = request.user
        category.save()
        messages.success(request, 'Category added successfully.')
        return redirect('category_list')
    return render(request, 'tracker/category_form.html', {'form': form, 'title': 'Add Category'})


@login_required
def category_edit(request, pk):
    category = get_object_or_404(Category, pk=pk, user=request.user)
    form = CategoryForm(request.POST if request.method == 'POST' else None, instance=category, user=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Category updated successfully.')
        return redirect('category_list')
    return render(request, 'tracker/category_form.html', {'form': form, 'title': 'Edit Category'})


@login_required
def category_delete(request, pk):
    category = get_object_or_404(Category, pk=pk, user=request.user)
    expense_count = category.expenses.count()
    if request.method == 'POST':
        if expense_count:
            # Expense.category uses PROTECT, so refuse politely instead of crashing.
            messages.error(request, f'Cannot delete "{category.name}" because it has {expense_count} expense(s). '
                                    'Move or delete those expenses first.')
            return redirect('category_list')
        category.delete()
        messages.success(request, 'Category deleted.')
        return redirect('category_list')
    return render(request, 'tracker/category_confirm_delete.html',
                  {'category': category, 'expense_count': expense_count})


# ---------- Monthly report ----------

@login_required
def monthly_report(request):
    today = timezone.localdate()
    error = None

    try:
        year = int(request.GET.get('year', today.year))
        month = int(request.GET.get('month', today.month))
        if not (1 <= month <= 12) or not (1900 <= year <= 2100):
            raise ValueError
    except ValueError:
        year, month = today.year, today.month
        error = 'Invalid year or month. Showing the current month instead.'

    expenses = Expense.objects.filter(user=request.user, date__year=year, date__month=month).select_related('category')

    # Optional date-range filter inside the selected month.
    start = parse_date(request.GET.get('start', ''))
    end = parse_date(request.GET.get('end', ''))
    if start:
        expenses = expenses.filter(date__gte=start)
    if end:
        expenses = expenses.filter(date__lte=end)

    total = expenses.aggregate(t=Sum('amount'))['t'] or 0
    category_totals = expenses.values('category__name').annotate(total=Sum('amount'), count=Count('id')).order_by('-total')
    labels, values = chart_data(expenses)

    context = {
        'year': year,
        'month': month,
        'month_name': calendar.month_name[month],
        'months': [(i, calendar.month_name[i]) for i in range(1, 13)],
        'years': range(today.year - 5, today.year + 2),
        'total': total,
        'category_totals': category_totals,
        'expenses': expenses,
        'chart_labels': labels,
        'chart_values': values,
        'start': request.GET.get('start', ''),
        'end': request.GET.get('end', ''),
        'error': error,
    }
    return render(request, 'tracker/monthly_report.html', context)
