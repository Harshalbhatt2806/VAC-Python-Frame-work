from decimal import Decimal

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models.functions import Lower


class Category(models.Model):
    """A personal spending category (Food, Travel...) owned by one user."""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='categories')
    name = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'categories'
        constraints = [
            # Same user cannot have two categories with the same name (case-insensitive).
            models.UniqueConstraint(
                Lower('name'), 'user', name='unique_category_name_per_user'
            ),
        ]

    def __str__(self):
        return self.name


class Expense(models.Model):
    """A single expense entry owned by one user."""

    PAYMENT_METHODS = [
        ('cash', 'Cash'),
        ('card', 'Credit/Debit Card'),
        ('upi', 'UPI'),
        ('bank', 'Bank Transfer'),
        ('other', 'Other'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='expenses')
    title = models.CharField(max_length=100)
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'), message='Amount must be greater than zero.')],
    )
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='expenses')
    date = models.DateField()
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS, default='cash')
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f'{self.title} - {self.amount:.2f}'

    def clean(self):
        # Keep the expense owner and category owner consistent.
        if self.category_id and self.user_id and self.category.user_id != self.user_id:
            raise ValidationError('The selected category does not belong to this user.')
