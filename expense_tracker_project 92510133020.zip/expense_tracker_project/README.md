# Expense Tracker (Django)

## Setup
    python -m venv venv
    source venv/bin/activate        # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    python manage.py makemigrations tracker
    python manage.py migrate
    python manage.py createsuperuser   # optional, for /admin/
    python manage.py runserver

Open http://127.0.0.1:8000/ and register an account.

## Tests
    python manage.py test

Optional production settings: set DJANGO_SECRET_KEY, DJANGO_DEBUG=False, DJANGO_ALLOWED_HOSTS.
